jQuery(function(){
    new DataTable('#tbl-employee')
    //Form Validation
    jQuery('#ems-frm-add-empolyee').validate();
});

jQuery(document).ready(function(){
    jQuery('#ems-frm-add-empolyee').submit(function(e){
        e.preventDefault(); // Prevent the default form submission
        // var ajaxurl = ajax_object.ajax_url;
// Access plugin URL
var pluginUrl = plugin_data.ajax_url;

// Now you can use the plugin URL as needed in your JavaScript code
console.log("Plugin URL: " + pluginUrl);

        // Serialize form data
        var formData = jQuery(this).serialize();
        console.log(formData);
        
        // AJAX request
        jQuery.ajax({
            url: pluginUrl,
            type: 'POST',
            action:"custom_form_submit",
            data: formData,
            success: function(response){
                // Handle success response
                console.log(response);
                // You can update UI or show success message here
            },
            error: function(xhr, status, error){
                // Handle error
                console.error(xhr.responseText);
                // You can display an error message or handle errors accordingly
            }
        });
    });
});
