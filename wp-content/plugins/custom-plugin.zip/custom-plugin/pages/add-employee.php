<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <h1><?php //echo esc_html(get_admin_page_title()); 
                ?></h1>

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
                </div>
                <div class="panel-body">
                    <form action="" method="POST" id="ems-frm-add-empolyee">
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" required class="form-control" id="name" placeholder="Enter name" name="name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" required class="form-control" id="email" placeholder="Enter email" name="email">
                        </div>
                        <div class="form-group">
                            <label for="phoneNo">Phone NO:</label>
                            <input type="text" class="form-control" id="phoneNo" placeholder="Enter phone number" name="phoneNo">
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <select name="gender" id="gender" class="form-control">
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation:</label>
                            <input type="text" class="form-control" id="designation" placeholder="Enter your designation" name="designation">
                        </div>
                        <button type="submit" class="btn btn-success" name="btn-submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// jQuery(document).ready(function(){
//     jQuery('button[type="submit"]').click(function(){
//         alert("test");
//         // Serialize form data
//         var formData = jQuery('#ems-frm-add-employee').serialize();
        
//         // AJAX request
//         // jQuery.ajax({
//         //     url: 'your-submit-url.php', // Replace with your PHP script URL
//         //     type: 'POST',
//         //     data: formData,
//         //     success: function(response){
//         //         // Handle success response
//         //         console.log(response);
//         //         // You can update UI or show success message here
//         //     },
//         //     error: function(xhr, status, error){
//         //         // Handle error
//         //         console.error(xhr.responseText);
//         //         // You can display an error message or handle errors accordingly
//         //     }
//         // });
//     });
// });
</script>
<?php
    // if(jQuery_SERVER['REQUEST_METHOD'] == 'POST' && isset(jQuery_POST['btn-submit'])){
    //     echo "<pre>";
    //     print_r(jQuery_POST);
    // }

?>